import { lib, game, ui, get, ai, _status } from "../../../noname.js";
import update from '../daoru/update.js';
//扩展设置
export const config = {
	"xinfan_Yuhun": {
		name: `<font color="#E661A0">开启 御魂<small>(下局生效)`,
		init: false,
		intro: `开启御魂后，游戏开始时，所有角色依次选择一个御魂(技能)获得<br>下局游戏生效`,
	},
	"xinfan_Bgm": {
		name: `<font color="#9c27b0">背景音乐随机播放的方式`,
                init: 2,
                item: {
					0: "关闭播放",
                    1: "单曲循环",
					2: "随机播放",
                },
				intro: `开启后，游戏开始时，随机播放一首歌，若开启随机播放，则在歌曲播放完成后，重新随机抽取一首歌`,
	},
	"xinfan_Bgms": {
		name: `<font color="#9c27b0">音乐包`,
                init: 0,
                item: {
					0: "全部音乐包",
					1: "阴阳师",
					2: "物华弥新",
                },
				intro: `若无对应音乐包，则默认“阴阳师”`,
	},
			update_method: {
				name: `<font color="#2196f3">极速更新`,
				init: false,
				intro: "开启后，在线更新将跳过音频、视频和图片等大文件，仅更新 .js 和 .css 代码文件，显著加快更新速度。",
			},
			auto_update: {
				name: `<font color="#e91e63">自动检测更新`,
				init: true,
				intro: "启动游戏时自动检查更新",
			},
			check_update: {
				name: `<span style="color:#4caf50;text-decoration: underline">检查更新`,
				clear: true,
				onclick: async function () {
					this.innerHTML = `<span style="color:#f61515ff;text-decoration: underline">正在检测更新...`;
					try {
						await update(true);
						this.innerHTML = `<span style="color:#4caf50;text-decoration: underline">更新完成`;
					} catch {
						this.innerHTML = `<span style="color:#f44336;text-decoration: underline">更新失败`;
					}
					setTimeout(() => {
						this.innerHTML = `<span style="color:#4caf50;text-decoration: underline">检查更新`;
					}, 2000);
				}
			},
};

//帮助内容
export const help = {};

//资源文件
export const files = {
	character: [],
	card: [],
	skill: [],
};
